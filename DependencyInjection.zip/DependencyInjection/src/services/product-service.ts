import { Component,Input } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'auction-product-item',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})

export class Product {
  
 
}


