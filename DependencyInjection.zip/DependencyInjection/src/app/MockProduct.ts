import {Component} from '@angular/core';
import {Product,ProductService} from './ProductService'


export class MockProductService implements ProductService{

    getProduct():Product{
            return new Product('Hello');
    }
}
