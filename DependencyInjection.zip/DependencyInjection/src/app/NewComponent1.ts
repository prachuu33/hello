import {Component} from '@angular/core';
import {Product,ProductService} from './ProductService'
import {NewComponent} from './NewComponent'
import {MockProductService} from './MockProduct'
@Component({
    selector:'NewComp1',
    template:`<h1>{{product.title}}<h1>`,
    providers:[{provide:ProductService,useClass:MockProductService}]
})

export class NewComponent1{

    product :Product;
    constructor(private productservice:ProductService)
    {
        this.product=productservice.getProduct();
    }

}