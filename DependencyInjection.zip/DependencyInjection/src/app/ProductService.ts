import {Component} from '@angular/core';


export class Product{
    constructor(public title:String){}
}

export class ProductService{

    getProduct():Product{
            return new Product('hi');
    }
}
