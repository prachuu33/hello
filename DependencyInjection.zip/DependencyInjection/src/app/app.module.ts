/**
 * Created by NamitaMalik on 9/27/2016.
 */
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {AppComponent} from './app.component';
import {Product,ProductService} from './ProductService'
import {NewComponent} from './NewComponent'
import {MockProductService} from './MockProduct'
import {NewComponent1} from './NewComponent1'
@NgModule({
    imports: [
        BrowserModule
    ],
   // providers:[ProductService,MockProductService],//one generic productService class at root level and another specific ProductService class
   providers:[{provide:ProductService,useClass:MockProductService}],//to override the implemtation of productserviceClass
    declarations: [
        AppComponent,
        NewComponent,
        NewComponent1
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}