
import {Component} from '@angular/core';
import {Product,ProductService} from './ProductService'
import {MockProductService} from './MockProduct'

@Component({
    selector: 'my-app',
    template: `<NewComp></NewComp>
                <NewComp1></NewComp1>`
})

export class AppComponent {
}