
import {Component} from '@angular/core';
import {Product,ProductService} from './ProductService'
import {MockProductService} from './MockProduct'

@Component({
    selector: 'NewComp',
    template: '<h1>{{product.title}}</h1>'
})

export class NewComponent {
 product:Product;

 constructor(private productService:ProductService)
 {
     this.product=productService.getProduct();
 }
}