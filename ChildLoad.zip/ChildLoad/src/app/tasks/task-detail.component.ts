/**
 * Created by NamitaMalik on 9/27/2016.
 */
import {Component} from '@angular/core';

@Component({
    template: `
    <div>
        <span>Some task detail to show up here.</span>
    </div>
    `
})

export class TaskDetailComponent {
}