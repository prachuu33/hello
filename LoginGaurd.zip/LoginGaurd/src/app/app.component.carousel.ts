import {Component} from '@angular/core';

@Component({

  selector: 'auction-product-item',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class CarouselComponent
{

}