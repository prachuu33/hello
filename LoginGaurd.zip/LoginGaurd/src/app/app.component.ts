import { Component } from '@angular/core';
import {Input,Output,EventEmitter} from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {HomeComponent} from './home';
import { AboutComponent } from './aboutUs'
import {routing} from './app.routing'
import {Router,Routes,RouterModule,ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})

 
export class AppComponent {
  ID:string
  artist:any;
  constructor(route:ActivatedRoute){
    this.ID=route.snapshot.params['id'];
    this.artist=[{
      name:'prachi',school:'school1'
    }]
    
  }
  
}


