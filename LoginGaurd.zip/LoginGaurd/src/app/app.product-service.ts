import { Component,Input } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'auction-product-item',
  

})

export class Product {
  
 
}


