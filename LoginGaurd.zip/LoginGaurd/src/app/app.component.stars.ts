import { Component,Input,OnInit } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'auction-starst',
  templateUrl: './app.component.star.html',
  styles:[`.starrating {color:#d17581}`]

})

export class StarsComponent implements OnInit{
  @Input() count:number=5;
  @Input() rating:number=0;
  stars:boolean[]=[];

    ngOnInit()
    {
       for(let i=1;i<=this.count;i++)
       {
         this.stars.push(i>this.rating);
       }
    }
}


