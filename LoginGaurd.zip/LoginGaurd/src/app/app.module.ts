import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { DatePickerModule } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {CarouselComponent} from './app.component.carousel'
import {FooterComponent} from './app.component.footer';
import {NavbarComponent} from './app.component.navbar';
import {ProductItemComponent} from './app.component.product-item';
import {SearchComponent} from './app.component.search';
import {StarsComponent} from './app.component.stars';
import {HomeComponent} from './home';
import {PrdComponent} from './app.product-details';
import { AboutComponent } from './aboutUs';
import {routing} from './app.routing';
import {LocationStrategy,HashLocationStrategy} from '@angular/common';
import {LoginGuard} from './LoginGuard'


@NgModule({
  declarations: [
    AppComponent,
    CarouselComponent,
    FooterComponent,
    NavbarComponent,
    ProductItemComponent,
    SearchComponent,
    StarsComponent,
    HomeComponent,
    AboutComponent,
    PrdComponent
  

    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    DatePickerModule,
    NgbModule.forRoot(),
    
    routing
    
  ],
  providers: [{provide:LocationStrategy,useClass:HashLocationStrategy},LoginGuard],
  bootstrap: [AppComponent],
 
})
export class AppModule { }
