
import { Component,Input } from '@angular/core';
import {StarsComponent} from './app.component.stars';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {Product} from './app.product-service'

@Component({
  selector: 'auction-product-item',
  templateUrl: './app.component.product-item.html'
})

export  class ProductItemComponent {
  @Input() product:Product;
 
}


