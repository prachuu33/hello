import { Component } from '@angular/core';
import {Input,Output,EventEmitter} from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'prod-details',
  template:`<h1>product details{{name}}</h1>
            <h1>{{school}}</h1>`,
  styles: ['.home {background:red']
})


export class PrdComponent {
  @Input() name:String;
  @Input() school:String;
}


