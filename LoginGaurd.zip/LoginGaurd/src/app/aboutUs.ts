import { Component } from '@angular/core';
import {Input,Output,EventEmitter} from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {Router,Routes,RouterModule,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'chat',
  template:`<h1>About Us {{name}}  {{school}}</h1>
            <nav>
              <a [routerLink]="['app.component.navbar']">app.component.navbar</a>
              <a [routerLink]="['app.component.search']">app.component.search</a>
           </nav>
          <router-outlet></router-outlet>
          <textarea placeholder="customer care"></textarea>`,
  styles: ['.about {background:green']
})

export class AboutComponent {
  @Input() name:String;
   @Input() school:String;
   constructor(route:ActivatedRoute){
    this.name=route.snapshot.params['name'];
    this.school=route.snapshot.params['school'];

  }
  
 
}


