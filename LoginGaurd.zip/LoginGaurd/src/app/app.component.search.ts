import { Component } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-root',
  template: '<h1>hi</h1>'
  

})

export class SearchComponent {
  
 
}


