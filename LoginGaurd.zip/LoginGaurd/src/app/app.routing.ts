import { Routes,RouterModule } from '@angular/router';
import {HomeComponent} from './home';
import { AboutComponent } from './aboutUs';
import { NavbarComponent } from './app.component.navbar';
import { SearchComponent } from './app.component.search';
import {LoginGuard} from './LoginGuard'


 const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full'},
  { path: 'home', component: HomeComponent },
  {path: 'app.component.navbar', component: NavbarComponent,outlet:"aux"},
  { path: 'aboutUs/:name/:school', component: AboutComponent,
    children: [
     // { path: '', redirectTo: 'app.component.navbar', pathMatch: 'full' },
     //{ path: 'app.component.navbar', component: NavbarComponent },
      { path: 'app.component.search', component: SearchComponent,canActivate:[LoginGuard] }
    ]
  }
];
export const routing =RouterModule.forRoot(routes);



