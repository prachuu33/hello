import {CanActivate,ActivatedRouteSnapshot,RouterStateSnapshot,Router} from "@angular/router";
import {Injectable} from "@angular/core";

@Injectable()

export class LoginGuard implements CanActivate{
    constructor(private router:Router){

    }
    canActivate(de:ActivatedRouteSnapshot,state:RouterStateSnapshot)
        {
               return window.confirm("you have unchanged chnages");
               // console.log(de.component.length);
                //return this.check();
        }
    private check()
    {
        let logger:boolean=Math.random()<0.5;
        if(!logger)
        {
            console.log("cant Login ")
        }
return logger;
    }

}