import { Component } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'auction-footer',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})

export class FooterComponent {
  
 
}


