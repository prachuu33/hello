import { Component } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'auction-navbar',
  template: `<h1>In NavBar</h1>`,
  

})

export class NavbarComponent {
  
 
}


