import { Component } from '@angular/core';
import {Input,Output,EventEmitter} from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'home',
  template:`<h1>home</h1>
            <input type="text" placeholder="type here"/>`,
  styles: ['.home {background:red']
})

export class HomeComponent {
  
 
}


